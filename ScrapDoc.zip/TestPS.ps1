﻿(Get-ChildItem "C:\Shakti\HWKG" -recurse).FullName |
  Foreach-Object {
   (Get-Content $_ -Raw).
     Replace('shakti','Shakti Swarup Patel').
     Replace('Address','B-1103, Mont Vert Tropez,WAKAD').
     Set-contains $_
  }
