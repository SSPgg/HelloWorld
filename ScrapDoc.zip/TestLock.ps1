﻿old_locked_state = 0
!Del::FileAppend, %A_Now% locked'n,autohotkey_log.txt
~#L::FileAppend, %A_Now% locked'n,autohotkey_log.txt

check_lock:
	if (!DllCall("User32\OpenInputDesktop","int",0*0,"int",0*0,"int",0x0001L*1))
		locked_state = 1
	else
		locked_state = 0

	if locked_state <> %old_locked_state%
	{
		if locked_state <> 1
			FileAppend %A_Now% unlocked`n,autohotkey_log.txt
		old_locked_state := locked_state
	}
returnnode